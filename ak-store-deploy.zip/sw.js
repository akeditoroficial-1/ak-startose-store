// AK Startose — service worker. Network-only on purpose: it makes the store and
// admin panel installable as apps, but never caches pages, so every update
// (from the admin panel or a new deploy) shows instantly.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", e => { e.respondWith(fetch(e.request)); });
