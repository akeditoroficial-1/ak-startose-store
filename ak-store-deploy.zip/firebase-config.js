// AK Startose store — Firebase config (same project as TubeChecker; orders collection: akstartose_orders)
window.STORE_FIREBASE = {
    apiKey: "AIzaSyC0-Anyjl6l04eCdJ4DjasQrWzkI8O55MQ",
    authDomain: "channel-analyzer-d1bc2.firebaseapp.com",
    projectId: "channel-analyzer-d1bc2",
    storageBucket: "channel-analyzer-d1bc2.firebasestorage.app",
    messagingSenderId: "1082106401856",
    appId: "1:1082106401856:web:f2730faff0e02a636cfba5"
  };
