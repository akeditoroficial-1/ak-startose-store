const PRODUCTS = [
 {
  "id": "watches",
  "name": "Golden Couple Watches — Pair of 2",
  "cat": "Watches",
  "price": 3499,
  "compare": 5000,
  "badge": "BEST SELLER",
  "imgs": [
   "img/products/watches/1.jpg",
   "img/products/watches/2.jpg"
  ],
  "desc": "Premium golden pair with diamond stones — the perfect gift for weddings, anniversaries and your loved one. Two watches, one price."
 },
 {
  "id": "serum",
  "name": "Skin Brightening Face Serum — 30ml",
  "cat": "Skin Care",
  "price": 1299,
  "compare": 2000,
  "badge": "BEST SELLER",
  "imgs": [
   "img/products/serum/1.jpg",
   "img/products/serum/2.jpg"
  ],
  "desc": "Lightweight daily serum that helps fade dullness and dark spots, leaving skin fresh, bright and glowing. Just a few drops for the full face."
 },
 {
  "id": "bundle",
  "name": "7-in-1 Skincare Bundle — Pack of 7",
  "cat": "Skin Care",
  "price": 2999,
  "compare": 4200,
  "badge": "BUNDLE",
  "imgs": [
   "img/products/bundle/1.jpg",
   "img/products/bundle/2.jpg",
   "img/products/bundle/3.jpg"
  ],
  "desc": "Complete skincare pack — 7 essential products in one box for a full daily care routine at one smart price."
 },
 {
  "id": "comb",
  "name": "Wireless Mini Hair Straightening Comb",
  "cat": "Hair Care",
  "price": 3999,
  "compare": 5500,
  "badge": "SALE",
  "imgs": [
   "img/products/comb/1.jpg",
   "img/products/comb/2.jpg",
   "img/products/comb/3.jpg"
  ],
  "desc": "Rechargeable straightening brush that smooths and styles hair in minutes — anytime, anywhere, no salon needed."
 },
 {
  "id": "foundation",
  "name": "24H Full Coverage Foundation",
  "cat": "Makeup",
  "price": 1499,
  "compare": 2200,
  "badge": null,
  "imgs": [
   "img/products/foundation/1.jpg",
   "img/products/foundation/2.jpg"
  ],
  "desc": "Full-coverage foundation with a smooth natural finish that lasts for hours — no cakey look, light on skin."
 },
 {
  "id": "blackhead",
  "name": "Electric Blackhead Remover",
  "cat": "Beauty Gadgets",
  "price": 1999,
  "compare": 2999,
  "badge": "SALE",
  "imgs": [
   "img/products/blackhead/1.jpg",
   "img/products/blackhead/2.jpg",
   "img/products/blackhead/3.jpg"
  ],
  "desc": "Powerful suction device that pulls out blackheads and extra oil at home — rechargeable, with multiple heads for every area."
 },
 {
  "id": "lipstick",
  "name": "Velvet Matte Lipstick",
  "cat": "Makeup",
  "price": 1799,
  "compare": 2500,
  "badge": null,
  "imgs": [
   "img/products/lipstick/1.jpg",
   "img/products/lipstick/2.jpg",
   "img/products/lipstick/3.jpg"
  ],
  "desc": "Soft velvet matte colour in one stroke that stays fresh all day without drying your lips."
 },
 {
  "id": "hairoil",
  "name": "Golden Hair Oil — 100ml",
  "cat": "Hair Care",
  "price": 2499,
  "compare": 3500,
  "badge": null,
  "imgs": [
   "img/products/hairoil/1.jpg",
   "img/products/hairoil/2.jpg",
   "img/products/hairoil/3.jpg"
  ],
  "desc": "Nourishing golden hair oil for stronger, shinier and smoother hair with regular use."
 },
 {
  "id": "teethpen",
  "name": "Teeth Whitening Pen",
  "cat": "Skin Care",
  "price": 899,
  "compare": 1400,
  "badge": "SALE",
  "imgs": [
   "img/products/teethpen/1.jpg",
   "img/products/teethpen/2.jpg",
   "img/products/teethpen/3.jpg"
  ],
  "desc": "Easy-apply whitening pen that helps make teeth visibly whiter and brighter — pocket size, use anywhere."
 },
 {
  "id": "pedi",
  "name": "Flawless Pedi Electronic Pedicure Tool",
  "cat": "Beauty Gadgets",
  "price": 1899,
  "compare": 2799,
  "badge": null,
  "imgs": [
   "img/products/pedi/1.jpg",
   "img/products/pedi/2.jpg",
   "img/products/pedi/3.jpg"
  ],
  "desc": "Electronic pedicure tool that gently removes dead and hard skin for soft, beautiful feet at home."
 },
 {
  "id": "cream",
  "name": "Anti-Aging Face Cream",
  "cat": "Skin Care",
  "price": 1599,
  "compare": 2399,
  "badge": null,
  "imgs": [
   "img/products/cream/1.jpg",
   "img/products/cream/2.jpg",
   "img/products/cream/3.jpg"
  ],
  "desc": "Deep-moisture anti-aging cream that helps with fine lines and dry skin — soft, smooth, glowing skin every day."
 },
 {
  "id": "facewash",
  "name": "Uni Whitening Face Wash",
  "cat": "Skin Care",
  "price": 599,
  "compare": 899,
  "badge": null,
  "imgs": [
   "img/products/facewash/1.jpg",
   "img/products/facewash/2.jpg",
   "img/products/facewash/3.jpg"
  ],
  "desc": "Daily whitening face wash that cleans deeply and leaves your face fresh and bright."
 },
 {
  "id": "eyebrow",
  "name": "2-in-1 Eyebrow & Nose Hair Remover",
  "cat": "Beauty Gadgets",
  "price": 1699,
  "compare": 2499,
  "badge": null,
  "imgs": [
   "img/products/eyebrow/1.jpg",
   "img/products/eyebrow/2.jpg",
   "img/products/eyebrow/3.jpg"
  ],
  "desc": "Rechargeable 2-in-1 trimmer for eyebrows and nose hair — quick, painless and precise."
 },
 {
  "id": "aloevia",
  "name": "Aloevia Face Wash — 100ml",
  "cat": "Skin Care",
  "price": 1399,
  "compare": 2099,
  "badge": null,
  "imgs": [
   "img/products/aloevia/1.jpg",
   "img/products/aloevia/2.jpg"
  ],
  "desc": "Gentle aloe face wash for a fresh, clean and calm skin feel — suitable for daily use."
 },
 {
  "id": "eyeshadow",
  "name": "Matte + Glitter Eyeshadow Kit — 48 Colours",
  "cat": "Makeup",
  "price": 1899,
  "compare": 2799,
  "badge": null,
  "imgs": [
   "img/products/eyeshadow/1.jpg",
   "img/products/eyeshadow/2.jpg"
  ],
  "desc": "48-shade eyeshadow palette with matte and glitter finishes for every look, day to party."
 },
 {
  "id": "roothair",
  "name": "Root Hair Oil",
  "cat": "Hair Care",
  "price": 1699,
  "compare": 2499,
  "badge": null,
  "imgs": [
   "img/products/roothair/1.jpg",
   "img/products/roothair/2.jpg"
  ],
  "desc": "Root-strengthening hair oil that nourishes from the roots for healthier, fuller-looking hair."
 },
 {
  "id": "cccream",
  "name": "CC Cream Liquid Foundation — 30ml",
  "cat": "Makeup",
  "price": 1199,
  "compare": 1799,
  "badge": null,
  "imgs": [
   "img/products/cccream/1.jpg",
   "img/products/cccream/2.jpg",
   "img/products/cccream/3.jpg"
  ],
  "desc": "Lightweight CC cream with pump dispenser — evens skin tone with a natural, fresh finish."
 },
 {
  "id": "marywash",
  "name": "Whitening Face Wash — 100ml",
  "cat": "Skin Care",
  "price": 1399,
  "compare": 2099,
  "badge": null,
  "imgs": [
   "img/products/marywash/1.jpg",
   "img/products/marywash/2.jpg",
   "img/products/marywash/3.jpg"
  ],
  "desc": "Whitening face wash for a brighter, cleaner complexion — gentle enough for everyday use."
 },
 {
  "id": "arvica",
  "name": "Whitening Skin Polish",
  "cat": "Skin Care",
  "price": 1299,
  "compare": 1899,
  "badge": null,
  "imgs": [
   "img/products/arvica/1.jpg",
   "img/products/arvica/2.jpg",
   "img/products/arvica/3.jpg"
  ],
  "desc": "Skin polish for brighter, smoother and glowing skin — removes dullness and refreshes your face."
 },
 {
  "id": "citriva",
  "name": "Vitamin C Face Wash — 100ml",
  "cat": "Skin Care",
  "price": 1399,
  "compare": 2099,
  "badge": null,
  "imgs": [
   "img/products/citriva/1.jpg",
   "img/products/citriva/2.jpg"
  ],
  "desc": "Vitamin C face wash that helps brighten skin and fight dullness with every wash."
 },
 {
  "id": "argan",
  "name": "Argan Hair Oil — 50ml",
  "cat": "Hair Care",
  "price": 899,
  "compare": 1399,
  "badge": null,
  "imgs": [
   "img/products/argan/1.jpg",
   "img/products/argan/2.jpg",
   "img/products/argan/3.jpg"
  ],
  "desc": "Pure argan nourishment for dry, frizzy and damaged hair — softness and shine without grease."
 },
 {
  "id": "lipset",
  "name": "12-Piece Lipstick & Lip Gloss Set",
  "cat": "Makeup",
  "price": 2999,
  "compare": 4399,
  "badge": null,
  "imgs": [
   "img/products/lipset/1.jpg",
   "img/products/lipset/2.jpg",
   "img/products/lipset/3.jpg"
  ],
  "desc": "Complete 12-piece matte lipstick and lip gloss set — a shade for every mood and occasion."
 },
 {
  "id": "keratin",
  "name": "Keratin & Vitamin B5 Hair Shampoo — 200ml",
  "cat": "Hair Care",
  "price": 1449,
  "compare": 2199,
  "badge": null,
  "imgs": [
   "img/products/keratin/1.jpg",
   "img/products/keratin/2.jpg",
   "img/products/keratin/3.jpg"
  ],
  "desc": "Keratin shampoo with Vitamin B5 for stronger, smoother and shinier hair after every wash."
 },
 {
  "id": "fegserum",
  "name": "FEG Plus Hair Serum — 50ml",
  "cat": "Hair Care",
  "price": 1249,
  "compare": 1899,
  "badge": null,
  "imgs": [
   "img/products/fegserum/1.jpg",
   "img/products/fegserum/2.jpg"
  ],
  "desc": "Hair growth support serum that nourishes roots and helps reduce hair fall with regular use."
 },
 {
  "id": "hairfall",
  "name": "Anti-Hair Fall Hair Oil — 150ml",
  "cat": "Hair Care",
  "price": 1799,
  "compare": 2699,
  "badge": null,
  "imgs": [
   "img/products/hairfall/1.jpg",
   "img/products/hairfall/2.jpg",
   "img/products/hairfall/3.jpg"
  ],
  "desc": "Advanced anti-hair-fall oil that strengthens roots and helps control hair fall naturally."
 },
 {
  "id": "acnecleanse",
  "name": "Acne Removal Cleansing Oil — 30ml",
  "cat": "Skin Care",
  "price": 2099,
  "compare": 3099,
  "badge": null,
  "imgs": [
   "img/products/acnecleanse/1.jpg",
   "img/products/acnecleanse/2.jpg",
   "img/products/acnecleanse/3.jpg"
  ],
  "desc": "Deep cleansing oil that helps clear acne and unclog pores while keeping skin soft."
 },
 {
  "id": "handcream",
  "name": "5-Piece Hand Cream Pack",
  "cat": "Skin Care",
  "price": 1799,
  "compare": 2699,
  "badge": null,
  "imgs": [
   "img/products/handcream/1.jpg",
   "img/products/handcream/2.jpg"
  ],
  "desc": "Set of 5 moisturising hand creams for soft, smooth and nourished hands all day."
 }
];
